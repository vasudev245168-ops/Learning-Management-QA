﻿Feature: NoticeAdmin

A short summary of the fA short summary of the feature
Background: 
	Given user is on login page
	Then user should be logged in successfully

@Create_And_View_Of_Template
Scenario: Verify creation of general Outage Template
	Given user should select the General Outage from Choose Template dropdown
	When user fills all the details
	When user selects an application group
	Then applications should display and select application
	Then user fill announcement content box
	And  user click on Save content template and  click on save
	When user navigates to My Applications
	Then user should be able to see the Important Notice and hover
	And  user should see the description by clicking on Show Content

@Search_Existing_Announcements
Scenario: Verify search existing announcements buttons funcitonality
Given  user is on Notice admins screen
When click on search existing announcements then all should display

@Get_User_Email_List
Scenario: Verify get user email list functionality
	Given user should select as template from Choose Template dropdown
	When  user click on get user email list buttons that all emails should display then cick on copy to clipboard

@Cancel_Button
Scenario: Verify Cancel button functionality
	When user is on notice admin screen and clicks on cancel buttons 
	Then  page should refresh and data should clear
	And user must logout on clicking the logout button
