﻿Feature: SessionExpiry

A short summary of the feature

Background: 
	Given user is on login page
	Then user should be logged in successfully

@Session_Expiry
Scenario: Validate session timeout functionality
	When user is idle for more than one  then Session timeout message should be displayed
	Then user clicks on Continue button, System remains on Same page
	And if user clicks on Logout button, System navigates to Logout page
