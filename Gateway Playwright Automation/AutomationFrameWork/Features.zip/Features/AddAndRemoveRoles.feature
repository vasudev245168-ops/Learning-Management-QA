﻿Feature: AddAndRemoveRoles

A short summary of the feature

Background: 
Given user is on login page
	Then user should be logged in successfully
	
@Notice_Admin_Role_Validation
Scenario: Validate Notice Admin Tab display before and after remove of Aministration role
	Given user is on My Applications Screen
	When user validates Notice admin tab display
	Then  Login to control center and remove administrator role
	Then Login back to Gateway and validate Notice Admin Tab should not display
	