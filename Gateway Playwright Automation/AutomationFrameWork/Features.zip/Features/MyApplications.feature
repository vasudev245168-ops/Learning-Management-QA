﻿Feature: MyApplications

A short summary of the feature
Background: 
	Given user is on login page
	Then user should be logged in successfully

@GatewayTabNavCheck
Scenario: Verify navigation functionality to all the tabs from My Applications tab
    Then user should click on My Reports and Notice Admin Tabs to verify navigation

@DragAndDropToMyFavorites
Scenario: Verify drag and drop of applications from Available applications to My Favorites
	Given user is on My Applications page
	When user drag and drop application from My Applications to My Favorites

@LaunchApplicationFromMyFavorite 
Scenario: Verify launch of applications from My Favourites Pane
	Then user access application from My Favorites

@RemoveAppsFromMyFavorites 
Scenario: Verify remove of applications from My Favorites pane
    Then user should be able to remove the applications from My favorites

@LaunchApplicationFromAvailableApplications
Scenario: Verify launch of applications from Available Applications
    Then  user access application from Available Applications
	And user must logout on clicking the logout button

