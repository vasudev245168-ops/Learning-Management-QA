﻿Feature: LaunchOfAllApplications

A short summary of the feature
Background: 
Given user is on login page
	Then user should be logged in successfully

@Launching_Applications
Scenario: Verify launch of all appplications successfully in each app area
	Given user is on My Applications page
	When  user click on logout then user logout from gateway
    Then user login to Control Center and assign all the roles in all app areas
	And user should be able to launch all the applications successfully in each app area