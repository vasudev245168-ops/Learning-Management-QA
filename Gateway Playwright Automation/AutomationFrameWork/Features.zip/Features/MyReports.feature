﻿Feature: MyReports

A short summary of the feature
Background: 
	Given user is on login page
	Then user should be logged in successfully

@Reports
Scenario: Verify reports functionality in My Reports Screen
	Given user is on reports screen
	When user should be able to see all the reports
	Then user should open all the reports 

And user must logout on clicking the logout button