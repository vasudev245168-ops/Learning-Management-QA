﻿using AutomationFrameWork.PageElements;
using AutomationFrameWork.Utilities;
using Microsoft.Playwright;

namespace AutomationFrameWork.PageActions
{
    public class MyReportsPages : MyReportsObjects
    {
        private readonly TestContext _context;
        private readonly IPage _page;

        public MyReportsPages(TestContext context, IPage page) : base(page)
        {
            _context = context;
            _page = page;
        }

        public async Task ClickOnMyReportsAsync()
        {
            await clickOnMyReportsTab.WaitForAsync();

            string reprotsTabText = await clickOnMyReportsTab.InnerTextAsync();
            await clickOnMyReportsTab.ClickAsync();
            string reportsHeaderText = await reportsScreenHeader.InnerTextAsync();
            Assert.Equal(reportsHeaderText.Trim(), reprotsTabText.Trim());
        }

        public async Task DisplayOfReportsAsync()
        {
            await clickOnMyReportsSortingIcon.WaitForAsync();
            await clickOnMyReportsSortingIcon.ClickAsync();
            Assert.True(await gatewayDropdownTextDispaly.IsVisibleAsync(), "Gateway Dropdown not  displayed in My reports screen");

            Assert.True(await userAccessReport.IsVisibleAsync(), "User Access Report not Displayed successfully in My reports screen");
          
            Assert.True(await employeeInactivityReport.IsVisibleAsync(), "Employee Inactivity Report not Displayed successfully in My reports screen");
           

        }

        public async Task LaunchOfUserAccessReportsAsync()
        {
            var userAccessReportPage = await _context.Page.RunAndWaitForPopupAsync(async () =>
            {
                await userAccessReport.WaitForAsync();
                await userAccessReport.ClickAsync();

            });
            await userAccessReportPage.WaitForLoadStateAsync();

           
            Assert.True(await reportsLoadsValidation.IsVisibleAsync(), "userAccessReport loaded successfully");
              
            await userAccessReportPage.CloseAsync();
            await Task.Delay(10000);
        }
        public async Task LaunchOfEmployeeInactivityReportsAsync()
        {
            var employeeInactivityReportPage = await _context.Page.RunAndWaitForPopupAsync(async () =>
        {
            await employeeInactivityReport.ClickAsync();

        });
            await employeeInactivityReportPage.WaitForLoadStateAsync();

                Assert.True(await reportsLoadsValidation.IsVisibleAsync(), "employeeInactivityReport  loaded successfully");
               
         
            await employeeInactivityReportPage.CloseAsync();
        }
    }
}
