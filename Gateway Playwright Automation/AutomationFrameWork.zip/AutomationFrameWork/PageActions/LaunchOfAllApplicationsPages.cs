﻿using AutomationFrameWork.PageElements;
using AutomationFrameWork.Utilities;
using AventStack.ExtentReports;
using Microsoft.Playwright;
namespace AutomationFrameWork.PageActions
{
    public class LaunchOfAllApplicationsPages : LaunchOfAllApplicationsObjects
    {
        private readonly TestContext _context;
        private readonly IPage _page;
        private readonly ScenarioContext _scenarioContext;
        public LaunchOfAllApplicationsPages(TestContext context, IPage page, ScenarioContext scenarioContext) : base(page)
        {
            _context = context;
            _page = page;
            _scenarioContext = scenarioContext;
        }
        private Dictionary<string, string> GetTestData()
        {
            var tagName = _context.ScenarioContext.ScenarioInfo.Tags
                            .First(t => !IsFrameworkTag(t));

            return ExcelHelper.ReadExcel(
                Config.DataFilesPath,
                "MyApplications",
                tagName
            );
        }
        private bool IsFrameworkTag(string tag)
        {
            var frameworkTags = new[] { "smoke", "regression", "sanity" };
            return frameworkTags.Contains(tag.ToLower());
        }
        public async Task LogoutFromGatewayAsync()
        {
            await AvailableApplicationSectionDisplay.WaitForAsync(new()
            {
                State = WaitForSelectorState.Visible,
                Timeout = 30000
            });
            await LogOutBtn.WaitForAsync();
            await LogOutBtn.Nth(0).ClickAsync();

            Console.WriteLine("** Clicked on logout button");

        }

        //Login to Control Center and assign all the roles related to all app areas
        public async Task AddAllRolesInControlCenterAsync()
        {
            var data = GetTestData();
            // Navigate to Add Employee screen
            await AddNewEmployeeScreenNavigate.WaitForAsync();
            await AddNewEmployeeScreenNavigate.ClickAsync();

            // Enter Employee ID
            await CorpLoginInputField.WaitForAsync();
            await CorpLoginInputField.FillAsync(data["EmployeeID"]);
            await CorpLoginInputField.PressAsync("Enter");

            // Wait for App Area dropdown
            await AppAreaDropdown.WaitForAsync();

            // Get all App Area options
            var appAreaOptions = AppAreaDropdown.Locator("option");
            int appAreaCount = await appAreaOptions.CountAsync();

            Console.WriteLine($"Total App Areas: {appAreaCount}");

            // Loop through every App Area
            for (int i = 0; i < appAreaCount; i++)
            {
                // Re locate options because the page may refresh after Save
                appAreaOptions = AppAreaDropdown.Locator("option");

                string appAreaValue =
                    await appAreaOptions.Nth(i).GetAttributeAsync("value");

                string appAreaName =
                    await appAreaOptions.Nth(i).InnerTextAsync();

                // Skip blank default option
                if (string.IsNullOrWhiteSpace(appAreaValue))
                    continue;

                Console.WriteLine(
                    $" Processing App Area: {appAreaName}");

                // Select App Area
                await AppAreaDropdown.SelectOptionAsync(
                    new SelectOptionValue
                    {
                        Value = appAreaValue
                    });

                // Wait for roles to refresh
                await Task.Delay(3000);

                // Get Available Roles


                int availableRoleCount =
                    await AvailableRoles.CountAsync();

                Console.WriteLine(
                    $"Available roles in {appAreaName}: {availableRoleCount}");

                // IF ROLES ARE AVAILABLE

                if (availableRoleCount > 0)
                {
                    Console.WriteLine(
                        $"Roles available. Clicking Add All for {appAreaName}");

                    // Click Add All
                    await ClickOnAddAllButton.WaitForAsync();
                    await ClickOnAddAllButton.ClickAsync();

                    await Task.Delay(2000);

                    // Save
                    await SaveButton.WaitForAsync();
                    await SaveButton.ClickAsync();

                    // Wait for confirmation popup
                    await UnsavedChangesPendingPopUp.WaitForAsync(new()
                    {
                        State = WaitForSelectorState.Visible,
                        Timeout = 10000
                    });

                    // Click Yes
                    await YesButton.ClickAsync();

                    // Wait until popup disappears
                    await UnsavedChangesPendingPopUp.WaitForAsync(new()
                    {
                        State = WaitForSelectorState.Hidden,
                        Timeout = 10000
                    });

                    Console.WriteLine(
                        $" All roles added and saved for {appAreaName}");
                }
                else
                {
                    Console.WriteLine(
                        $" No available roles for {appAreaName}. Skipping.");
                }

                // Small wait before moving to next App Area
                await Task.Delay(2000);
            }

            Console.WriteLine("========== All App Areas processed ==========");
        }

        //Validate launch of all applications from Gateway
        public async Task LaunchApplicationFromMyApplicationsTabAsync()
        {
            var extentScenario = _scenarioContext.Get<ExtentTest>("ExtentScenario");
            var appAreas = _page.Locator(
                "//li[contains(@class,'rtLI') and .//span[contains(@class,'rtPlus') or contains(@class,'rtMinus')]]");

            int areaCount = await appAreas.CountAsync();

            for (int i = 0; i < areaCount; i++)
            {
                var currentArea = appAreas.Nth(i);

                // Expand app area
                var expandIcon = currentArea.Locator(":scope > div .rtPlus");

                if (await expandIcon.CountAsync() > 0)
                {
                    await expandIcon.ClickAsync();
                    await _page.WaitForTimeoutAsync(500);
                }

                // Get all applications in this area
                var appsInArea = currentArea.Locator(
                    ":scope > ul > li a.rtIn");

                int appCount = await appsInArea.CountAsync();

                Console.WriteLine(
                    $"\nApp Area {i + 1} - Applications: {appCount}");

                // Launch every application
                for (int j = 0; j < appCount; j++)
                {
                    var app = currentArea
                        .Locator(":scope > ul > li a.rtIn")
                        .Nth(j);

                    string appName = (await app.InnerTextAsync()).Trim();

                    Console.WriteLine(
                        $"\nLaunching Application: {appName}");

                    // Create separate Extent node for this application
                    var appTest = extentScenario.CreateNode(appName);

                    appTest.Info($"Launching Application: {appName}");

                    IPage? newPage = null;

                    try
                    {
                        // Wait for new tab
                        var pageTask = _page.Context.WaitForPageAsync(
                            new() { Timeout = 30000 });

                        // Click application
                        await app.ClickAsync(new() { Force = true });

                        // Get new tab
                        newPage = await pageTask;

                        Console.WriteLine($"Opened URL: {newPage.Url}");

                        appTest.Info($"Opened URL: {newPage.Url}");

                        // Wait for DOM to load
                        try
                        {
                            await newPage.WaitForLoadStateAsync(
                                LoadState.DOMContentLoaded,
                                new() { Timeout = 30000 });
                        }
                        catch (TimeoutException)
                        {
                            string message =
                                "Page did not load within 30 seconds";

                            Console.WriteLine(
                                $"FAIL - {appName} - {message}");

                            appTest.Fail(message);

                            continue;
                        }

                        appTest.Info("DOM loaded successfully");


                        // Validate application
                        var loggedInName = newPage.Locator(
                            "//span[contains(@id,'lblUserName')]");

                        var loginAndLogout = newPage.Locator(
                            "[id='pnlTopLHead']");

                        var docExtractionValidate = newPage.Locator(
                            "[title='My Documents']");

                        var hedgeTrackerValidate = newPage.Locator(
                            "//a[text()='Hedge Rates']");

                        var servicingComplianceValidate = newPage.Locator(
                            "//span[text()='Search']").Nth(0);

                        var spreadingAppValidate = newPage.Locator(
                            "//a[text()='Spreading']");

                        var spreadingWorkflowValidate = newPage.Locator(
                            "[id='assignLoansTo']");

                        bool applicationValidated = false;

                        // 1. Validate logged-in user
                        try
                        {
                            await loggedInName.WaitForAsync(
                                new() { Timeout = 3000 });

                            if (await loggedInName.IsVisibleAsync())
                            {
                                Console.WriteLine(
                                    $"PASS - {appName} - Application launched and user is logged in");

                                appTest.Pass(
                                    "Application launched and user is logged in");

                                applicationValidated = true;
                            }
                        }
                        catch
                        {
                            throw new Exception(
                                $"FAIL - {appName} - Application did not launch successfully or user is not logged in");    
                        }

                        // 2. Validate Login/Logout section
                        if (!applicationValidated)
                        {
                            try
                            {
                                await loginAndLogout.WaitForAsync(
                                    new() { Timeout = 3000 });

                                if (await loginAndLogout.IsVisibleAsync())
                                {
                                    Console.WriteLine(
                                        $"PASS - {appName} - Login/Logout section is displayed");

                                    appTest.Pass(
                                        "Login/Logout section is displayed");

                                    applicationValidated = true;
                                }
                            }
                            catch
                            {
                                throw new Exception(
                                    $"FAIL - {appName} - Application did not launch successfully or user is not logged in");
                            }
                        }

                        // 3. Validate My Documents
                        if (!applicationValidated)
                        {
                            try
                            {
                                await docExtractionValidate.WaitForAsync(
                                    new() { Timeout = 3000 });

                                if (await docExtractionValidate.IsVisibleAsync())
                                {
                                    Console.WriteLine(
                                        $"PASS - {appName} - My Documents is displayed");

                                    appTest.Pass(
                                        "My Documents is displayed");

                                    applicationValidated = true;
                                }
                            }
                            catch
                            {
                                throw new Exception(
                                    $"FAIL - {appName} - Application did not launch successfully or user is not logged in");
                            }
                        }

                        // 4. Validate Hedge Tracker
                        if (!applicationValidated)
                        {
                            try
                            {
                                await hedgeTrackerValidate.WaitForAsync(
                                    new() { Timeout = 3000 });

                                if (await hedgeTrackerValidate.IsVisibleAsync())
                                {
                                    Console.WriteLine(
                                        $"PASS - {appName} - Hedge Rates is displayed");

                                    appTest.Pass(
                                        "Hedge Rates is displayed");

                                    applicationValidated = true;
                                }
                            }
                            catch
                            {
                                throw new Exception(
                                    $"FAIL - {appName} - Application did not launch successfully or user is not logged in");
                            }
                        }

                        // 5. Validate Servicing Compliance
                        if (!applicationValidated)
                        {
                            try
                            {
                                await servicingComplianceValidate.WaitForAsync(
                                    new() { Timeout = 3000 });

                                if (await servicingComplianceValidate.IsVisibleAsync())
                                {
                                    Console.WriteLine(
                                        $"PASS - {appName} - Search is displayed");

                                    appTest.Pass(
                                        "Search is displayed");

                                    applicationValidated = true;
                                }
                            }
                            catch
                            {
                                throw new Exception(
                                    $"FAIL - {appName} - Application did not launch successfully or user is not logged in");
                            }
                        }

                        // 6. Validate Spreading
                        if (!applicationValidated)
                        {
                            try
                            {
                                await spreadingAppValidate.WaitForAsync(
                                    new() { Timeout = 3000 });

                                if (await spreadingAppValidate.IsVisibleAsync())
                                {
                                    Console.WriteLine(
                                        $"PASS - {appName} - Spreading is displayed");

                                    appTest.Pass(
                                        "Spreading is displayed");

                                    applicationValidated = true;
                                }
                            }
                            catch
                            {
                                throw new Exception(
                                    $"FAIL - {appName} - Application did not launch successfully or user is not logged in");
                            }
                        }

                        // 7. Validate Spreading Workflow
                        if (!applicationValidated)
                        {
                            try
                            {
                                await spreadingWorkflowValidate.WaitForAsync(
                                    new() { Timeout = 3000 });

                                if (await spreadingWorkflowValidate.IsVisibleAsync())
                                {
                                    Console.WriteLine(
                                        $"PASS - {appName} - Spreading Workflow is displayed");

                                    appTest.Pass(
                                        "Spreading Workflow is displayed");

                                    applicationValidated = true;
                                }
                            }
                            catch
                            {
                                throw new Exception(
                                    $"FAIL - {appName} - Application did not launch successfully or user is not logged in");
                            }
                        }

                        // 8. Final validation
                        if (!applicationValidated)
                        {
                            string url = newPage.Url;

                            if (url.Contains("Dashboard") ||
                                url.Contains("default.aspx"))
                            {
                                Console.WriteLine(
                                    $"PASS - {appName} - Application loaded successfully");

                                appTest.Pass(
                                    "Application loaded successfully based on URL");
                            }
                            else if (url.Contains(
                                "login.microsoftonline.com"))
                            {
                                Console.WriteLine(
                                    $"FAIL - {appName} - SSO redirect issue");

                                appTest.Fail(
                                    "SSO redirect issue");

                                appTest.Info(
                                    $"Redirect URL: {url}");
                            }
                            else
                            {
                                Console.WriteLine(
                                    $"FAIL - {appName} - Page not loaded successfully");

                                appTest.Fail(
                                    "Page not loaded successfully");

                                appTest.Info(
                                    $"URL: {url}");
                            }
                        }
                    }
                    catch (TimeoutException)
                    {
                        string message =
                            "New page did not open within 30 seconds";

                        Console.WriteLine(
                            $"FAIL - {appName} - {message}");

                        appTest.Fail(message);

                        continue;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(
                            $"FAIL - {appName} - {ex.Message}");

                        appTest.Fail(
                            $"Application launch failed: {ex.Message}");

                        continue;
                    }
                    finally
                    {
                        // Close the new tab if it was created
                        if (newPage != null && !newPage.IsClosed)
                        {
                            await newPage.CloseAsync();

                            Console.WriteLine(
                                $"Closed application tab: {appName}");

                            appTest.Info(
                                "Application tab closed");
                        }
                    }
                }
            }
        }
    }
}
