﻿using AutomationFrameWork.PageElements;
using AutomationFrameWork.Utilities;
using Microsoft.Playwright;

namespace AutomationFrameWork.PageActions
{
    public class AddAndRemoveRolesPages : AddAndRemoveRolesObjects
    {
        private readonly TestContext _context;
        private readonly IPage _page;

        public AddAndRemoveRolesPages(TestContext context, IPage page) : base(page)
        {
            _context = context;
            _page = page;
        }
        //Gateway Notice admin Tab Display validation

        public async Task NavigatedToMyApplicationsTabAsync()
        {
            await MyApplicationsNavigation.WaitForAsync();
            Assert.True(await MyApplicationsNavigation.IsVisibleAsync(), "My Applications Screen not displayed");

        }
        public async Task NoticeAdminTabDisplayAsync()
        {
            await NoticeAdminTabDisplay.WaitForAsync();
            await NoticeAdminTabDisplay.IsVisibleAsync();

            Assert.True(await NoticeAdminTabDisplay.IsVisibleAsync(), "Notice Admin tab not displayed");
           
            await ClickLogoutButton.WaitForAsync();
            await ClickLogoutButton.ClickAsync();
        }

        //Login to Control Center and remove Admin user role
        public async Task RemoveOfRoleFromControlCenterAsync(ILocator availableRole, ILocator roleToRemove, ILocator buttonToClick)
        {
            await AddNewEmployeeScreenNavigate.WaitForAsync();
            await AddNewEmployeeScreenNavigate.ClickAsync();

            await CorpLoginInputField.WaitForAsync();
            await CorpLoginInputField.IsVisibleAsync();
            await CorpLoginInputField.FillAsync("T11526");
            await CorpLoginInputField.PressAsync("Enter");

            await AppAreaDropdown.WaitForAsync();
            await AppAreaDropdown.ClickAsync();

            await AppAreaDropdown.SelectOptionAsync(
            new SelectOptionValue { Label = "COR" });
            //Available roles check fro removing role

            await GatewayApplicationAccess.WaitForAsync();
            await GatewayApplicationAccess.IsVisibleAsync();    
            await SecurityAdminAccess.WaitForAsync();
            await SecurityAdminAccess.IsVisibleAsync();
            bool roleAvailable = await availableRole.CountAsync() > 0;

            if (roleAvailable)
            {
                Console.WriteLine($"{availableRole} is available. Adding it first...");

                // Select role
                await availableRole.WaitForAsync();
                await availableRole.ClickAsync();

                // Add role to Current Roles
                await AddButton.WaitForAsync();
                await AddButton.ClickAsync();
                await Task.Delay(2000);

                // Save
                await SaveButton.WaitForAsync();
                await SaveButton.ClickAsync();
                await Task.Delay(6000);

                // Confirm
                await UnsavedChangesPendingPopUp.WaitForAsync(new()
                {
                    State = WaitForSelectorState.Visible,
                    Timeout = 10000
                });

                await YesButton.WaitForAsync();
                await YesButton.ClickAsync();
                await Task.Delay(2000);

            }

            //Remove role from Current Roles
            await roleToRemove.WaitForAsync();
            bool removalRoleInCurrentRole = await roleToRemove.IsVisibleAsync();
            if (removalRoleInCurrentRole)
            {
                await roleToRemove.WaitForAsync();
                await roleToRemove.ClickAsync();
            }
            else
            {
                throw new Exception(" role is already removed from current access and you don't have access relating to the role...");
            }

            await buttonToClick.WaitForAsync();
            await buttonToClick.ClickAsync();
            await Task.Delay(2000);

            await SaveButton.ClickAsync();
            await Task.Delay(6000);

            // Confirm
            await UnsavedChangesPendingPopUp.WaitForAsync(new()
            {
                State = WaitForSelectorState.Visible,
                Timeout = 10000
            });

            await YesButton.WaitForAsync();
            await YesButton.ClickAsync();
            await Task.Delay(2000);

        }
       
        public async Task RemoveAdminUserRoleFromControlCenterAsync()
        {
            await RemoveOfRoleFromControlCenterAsync(AvailableRolesAnnouncementAdminRole, CurrentRolesAnnouncementAdminRole, RemoveButton);
        }

        //Login back to Gatewy and validate Notice admin Side menu
        public async Task ValidateNoticeAdminTabRemoveAsync()
        {
            await _page.WaitForLoadStateAsync(LoadState.NetworkIdle);

            Assert.True(!await NoticeAdminTabDisplay.IsVisibleAsync(), "Announcement administrator tab removed successfully, and access also removed...");
           
        }
    }
}
