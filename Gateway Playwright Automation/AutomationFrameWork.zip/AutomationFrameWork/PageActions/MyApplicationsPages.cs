﻿using AutomationFrameWork.Models;
using AutomationFrameWork.PageElements;
using AutomationFrameWork.Utilities;
using Microsoft.Playwright;
namespace AutomationFrameWork.PageActions
{
    public class MyApplicationsPages : MyApplicationsObjects
    {
        private readonly TestContext _context;
        private readonly IPage _page;

        public MyApplicationsPages(TestContext context, IPage page) : base(page)
        {
            _context = context;
            _page = page;
        }
        //Navigation Check
        public async Task GatewayTabsNavAsync()
        {
            Assert.True(await headerMyReportsNavCheck.IsVisibleAsync(), "My Applications tab is not visible in the header");
           
            await _page.GoBackAsync();

            Assert.True(await headerNoticeAdminNavCheck.IsVisibleAsync(), "Notice Admin tab is not visible in the header");
           
            await _page.GoForwardAsync();

        }

        //
        public async Task MyApplicationsScreenValidationAsync()
        {
            await UsernameDisplay.WaitForAsync(new()
            {
                State = WaitForSelectorState.Visible,
                Timeout = 30000
            });
            Assert.True(await UsernameDisplay.IsVisibleAsync(), "Username display is not visible in the header");

            await AvailableApplicationSectionDisplay.WaitForAsync(new()
            {
                State = WaitForSelectorState.Visible,
                Timeout = 30000
            });

        }
        //DragAndDropToMyFavorites     *** START  *******


        public async Task DragFirstAppFromEachArea()
        {
            int count = await AllAppAreas.CountAsync();

            for (int i = 0; i < count; i++)
            {
                var currentArea = AllAppAreas.Nth(i);

                var expandIcon = currentArea.Locator(":scope > div > .rtPlus");

                if (await expandIcon.CountAsync() > 0)
                {
                    await expandIcon.ClickAsync();

                    // wait for latest visible node
                    await _page.Locator("ul[style*='overflow: visible'] .rtIn").Last.WaitForAsync();
                }

                var source = _page.Locator("ul[style*='overflow: visible'] .rtIn").Last;

                var target = dragToLocator;

                var sourceBox = await source.BoundingBoxAsync();
                var targetBox = await target.BoundingBoxAsync();

                if (sourceBox == null || targetBox == null)
                    continue;
                await _page.Mouse.MoveAsync(sourceBox.X + sourceBox.Width / 2, sourceBox.Y + sourceBox.Height / 2);
                await _page.Mouse.DownAsync();
                await _page.Mouse.MoveAsync(targetBox.X + targetBox.Width / 2, targetBox.Y + 10);
                await _page.Mouse.UpAsync();

                await _page.WaitForTimeoutAsync(700);

                var collapseIcon = currentArea.Locator(":scope > div > .rtMinus");

                if (await collapseIcon.CountAsync() > 0)
                {
                    await collapseIcon.ClickAsync();
                    await _page.WaitForTimeoutAsync(500);
                }
            }
        }
        //DragAndDropToMyFavorites     *** END  *******


        //LaunchApplicationFromMyFavorite     *** START  *******
        public async Task<(string Status, string Message)> ValidateAppPage(IPage newPage)
        {
            var loggedInName = newPage.Locator("//span[contains(@id,'lblUserName')]");
            var url = newPage.Url;

            try
            {
                // Primary check  Trimont logo
                await loggedInName.WaitForAsync(new() { Timeout = 5000 });
                return ("PASS", "Trimont logo displayed");
            }
            catch
            {
                //  Secondary check  URL-based PASS
                if (url.Contains("default.aspx") || url.Contains("Dashboard"))
                    return ("PASS", "Loaded successfully (URL match)");

                //  Failure cases
                if (await newPage.Locator("text=The resource you are looking for").IsVisibleAsync())
                    return ("FAIL", "App not available");

                if (await newPage.Locator("text=An error occurred while processing your request").IsVisibleAsync())
                    return ("FAIL", "Internal error");

                if (url.Contains("login.microsoftonline.com"))
                    return ("FAIL", "SSO redirect issue");

                return ("FAIL", "Trimont logo not found / Unknown behavior");
            }
        }


        public async Task<List<AppResult>> LaunchAppAsync()
        {
            var results = new List<AppResult>();

            var apps = launchFirstAppForEachArea;
            int count = await apps.CountAsync();

            for (int i = 0; i < count; i++)
            {
                var app = apps.Nth(i);

                if (await app.IsVisibleAsync())
                {
                    var appName = await app.InnerTextAsync();

                    var pageTask = _page.Context.WaitForPageAsync();
                    await app.ClickAsync();
                    var newPage = await pageTask;

                    await newPage.WaitForLoadStateAsync();

                    var (status, message) = await ValidateAppPage(newPage);

                    results.Add(new AppResult
                    {
                        AppName = appName,
                        Status = status,
                        Message = message
                    });

                    await newPage.CloseAsync();
                }
            }

            return results;
        }
        //LaunchApplicationFromMyFavorite     *** END  *******

        //RemoveAll Apps From My Favorites    ***START  ****
        public async Task RemoveAllAppsFromMyFavoritesAsync()
        {
            var removeIcons = _page.Locator("input[type='image'][src*='cancel']");
            int countofremoveicons = await removeIcons.CountAsync();
            if (countofremoveicons > 0)
            {

                while (await removeIcons.CountAsync() > 0)
                {

                    var firstRemove = removeIcons.First;

                    await firstRemove.WaitForAsync();
                    await firstRemove.ClickAsync();

                    await _page.WaitForLoadStateAsync(LoadState.NetworkIdle);

                    await _page.WaitForTimeoutAsync(500);
                }
            }
            else
            {
                await noRecordsFoundInMyFavorites.WaitForAsync();

                string text = (await noRecordsFoundInMyFavorites.InnerTextAsync()).Trim();

                if (text == "No records to display.")
                {
                    Console.WriteLine(" No records to display in My Favorites");
                }


            }
        }

        //Remove All Apps From My Favorites    ***END  ****

        //Launch applications from My Applications
        public async Task LaunchApplicationFromMyApplicationsTabAsync()
        {
            var appAreas = _page.Locator("//li[contains(@class,'rtLI') and .//span[contains(@class,'rtPlus') or contains(@class,'rtMinus')]]");
            int count = await appAreas.CountAsync();

            for (int i = 0; i < count; i++)
            {
                var currentArea = appAreas.Nth(i);

                Console.WriteLine($"\n➡ Processing Area {i + 1}");

                // Expand ONLY this area
                var expandIcon = currentArea.Locator(":scope > div .rtPlus");

                if (await expandIcon.IsVisibleAsync())
                {
                    await expandIcon.ClickAsync();
                }

                // Wait until THIS area's apps load (critical)
                var appsInArea = currentArea.Locator(":scope > ul > li a.rtIn");

                if (await appsInArea.CountAsync() == 0)
                {
                    Console.WriteLine(" No apps in this area");
                    continue;
                }

                await appsInArea.First.WaitForAsync();

                var firstApp = appsInArea.First;

                string appName = await firstApp.InnerTextAsync();
                Console.WriteLine($"Opening: {appName}");

                await firstApp.ScrollIntoViewIfNeededAsync();

                // Open new tab
                var pageTask = _page.Context.WaitForPageAsync();
                await _page.WaitForLoadStateAsync(LoadState.DOMContentLoaded);
                await firstApp.ClickAsync(new() { Force = true });

                var newPage = await pageTask;

                await newPage.WaitForLoadStateAsync();
                await newPage.WaitForLoadStateAsync(LoadState.DOMContentLoaded);
                Console.WriteLine($"Opened URL: {newPage.Url}");

                await newPage.CloseAsync();

                // Collapse THIS area before moving next
                var collapseIcon = currentArea.Locator(":scope > div .rtMinus");

                if (await collapseIcon.IsVisibleAsync())
                {
                    await collapseIcon.ClickAsync();
                }
                else
                {
                    throw new Exception("Collapse icon not found after opening app");
                }
                await _page.WaitForTimeoutAsync(300);
            }

        }
    }
}