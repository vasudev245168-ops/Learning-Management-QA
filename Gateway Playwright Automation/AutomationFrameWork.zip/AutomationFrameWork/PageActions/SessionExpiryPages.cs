﻿using AutomationFrameWork.PageElements;
using AutomationFrameWork.Utilities;
using Microsoft.Playwright;
using static Microsoft.Playwright.Assertions;

namespace AutomationFrameWork.PageActions
{
    public class SessionExpiryPages : SessionExpiryObjects
    {
        private readonly TestContext _context;
        private readonly IPage _page;

        public SessionExpiryPages(TestContext context, IPage page) : base(page)
        {
            _context = context;
            _page = page;
        }
        private string URL1 = "https://app-gty-ui-sit-eus2.ase-cms-dev-eus2-01.appserviceenvironment.net/MyApplications.aspx";
        public async Task ValidateSessionReminderMessage()
        {
            await SessionReminderHeader.WaitForAsync();
            await Expect(SessionReminderHeader)
                    .ToHaveTextAsync("Session Reminder");
            await SessionTimeoutText.WaitForAsync();
            await Expect(SessionTimeoutText)
                    .ToHaveTextAsync("Your session in Gateway is about to time out. Would you like to continue?");
        }

        public async Task ValidateContinueButtonFunctionality()
        {

            await ContinueBtn.WaitForAsync();
            await ContinueBtn.ClickAsync();
            await Assertions.Expect(_page).ToHaveURLAsync(URL1);

        }

        public async Task ValidateLogoutButtonFunctionality()
        {
            await LogoutBtn.WaitForAsync();
            await LogoutBtn.ClickAsync();
            await ClickhereTextlink.WaitForAsync();
            await ClickhereTextlink.ClickAsync();
            if (await SignoutAccount.IsVisibleAsync())
            {
                await SignoutAccount.ClickAsync();
            }
            else
            {
                throw new Exception("SignoutAccount element is not visible.");
            }
            await SuccessfulLogoutMsg.WaitForAsync();
            await Expect(SuccessfulLogoutMsg)
                     .ToHaveTextAsync("You signed out of your account");
        }

    }
}

