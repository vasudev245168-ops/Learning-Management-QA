﻿using AutomationFrameWork.PageElements;
using AutomationFrameWork.Utilities;
using Microsoft.Playwright;

namespace AutomationFrameWork.PageActions;

public class LoginPages : LoginObjects
{
    private readonly TestContext _context;

    public LoginPages(TestContext context, IPage page) : base(page)
    {
        _context = context;
    }

    public async Task NavigateAsync(string url)
    {
        if (string.IsNullOrWhiteSpace(url))
            throw new ArgumentException("URL cannot be null or empty", nameof(url));

        await _context.Page.GotoAsync(url);

        if (File.Exists("auth.json"))
        {
            await Task.Delay(15000);

            await SaveAuthStateAsync();
        }
    }
    public async Task SaveAuthStateAsync()
    {
        await _context.Page.Context.StorageStateAsync(new() { Path = "auth.json" });
    }
    public async Task LoginAsync(string userName, string password)
    {
        if (string.IsNullOrWhiteSpace(userName))
            throw new ArgumentException("Username cannot be null or empty", nameof(userName));

        if (string.IsNullOrWhiteSpace(password))
            throw new ArgumentException("Password cannot be null or empty", nameof(password));
        await EmailTextField.WaitForAsync();
        await EmailTextField.FillAsync(userName);

        await ClickOnNextButton.WaitForAsync();
        await ClickOnNextButton.ClickAsync();

        await PasswordTextField.WaitForAsync();
        await PasswordTextField.FillAsync(password);

        await ClickOnSignInBtn.WaitForAsync();
        await ClickOnSignInBtn.ClickAsync();

        Console.WriteLine("** Username, Password entered and login button clicked");

        await _context.Page.WaitForLoadStateAsync(LoadState.NetworkIdle);
        _context.CommonActions.LogCurrentPageUrl();
    }
    public async Task LogoutAsync()
    {

        await LogOutBtn.WaitForAsync();
        await LogOutBtn.Nth(0).ClickAsync();

        Console.WriteLine("** Clicked on logout button");

        await _context.Page.WaitForLoadStateAsync(LoadState.NetworkIdle);
    }
}