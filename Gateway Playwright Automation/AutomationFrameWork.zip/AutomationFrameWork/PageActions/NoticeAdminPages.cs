﻿using AutomationFrameWork.PageElements;
using AutomationFrameWork.Utilities;
using Microsoft.Playwright;

namespace AutomationFrameWork.PageActions
{
    public class NoticeAdminPages : NoticeAdminObjects
    {
        private readonly TestContext _context;
        private readonly IPage _page;

        public NoticeAdminPages(TestContext context, IPage page) : base(page)
        {
            _context = context;
            _page = page;
        }
        private Dictionary<string, string> GetTestData()
        {
            var tagName = _context.ScenarioContext.ScenarioInfo.Tags
                            .First(t => !IsFrameworkTag(t));

            return ExcelHelper.ReadExcel(
                Config.DataFilesPath,
                "NoticeAdmin",
                tagName
            );
        }
        private bool IsFrameworkTag(string tag)
        {
            var frameworkTags = new[] { "smoke", "regression", "sanity" };
            return frameworkTags.Contains(tag.ToLower());
        }
        public async Task clickOnNoticeAdminAsync()
        {
            await clickNoticeAdminTab.ClickAsync();

        }
        public async Task GeneralOutageDropdownSelectAsync()
        {
            var data = GetTestData();
            await clickOnChooseTemplateDropdown.ClickAsync();
            await selectGeneralOutageOption.ClickAsync();
            await enterDataIntoTitleFiled.FillAsync(data["Title"]);
            await Task.Delay(5000);

        }

        public async Task SelectDefaultDatesAsync()
        {
            var start = DateTime.Now.AddDays(-1).Date
                          .ToString("M/d/yyyy h:mm tt");

            var end = DateTime.Now.AddDays(1).Date
                        .AddHours(23).AddMinutes(59)
                        .ToString("M/d/yyyy h:mm tt");

            // Start Date
            await startDate.ClickAsync();
            await startDate.FillAsync("");
            await startDate.TypeAsync(start);
            await startDate.PressAsync("Tab");

            // Wait for UI sync
            await _page.WaitForTimeoutAsync(500);

            // End Date
            await endDate.ClickAsync();
            await endDate.FillAsync("");
            await endDate.TypeAsync(end);
            await endDate.PressAsync("Tab");
        }
        public async Task SelectApplicationGroupAsync()
        {
            await clickapplicationGroupDropdown.ClickAsync();

            await selectLoanServicingApplication.Nth(0).ClickAsync();
        }
        public async Task SelectApplicationNameAsync()
        {
            string selectedAppName = await selectApplicationName.InnerTextAsync();
            await selectApplicationName.ClickAsync();
        }
        public async Task AnnounemetnContentBoxFillAsync()
        {
            var data = GetTestData();

            await enterAnnouncementContent.FillAsync(data["Announcement_Content"]);
        }
        public async Task SaveAsTemplateAsync()
        {
            await clickOnSaveContentTemplate.WaitForAsync();
            await clickOnSaveContentTemplate.ClickAsync();


        }
        public async Task ClickOnContentTemaplateAndSAveBTnAsync()
        {
            await clickOnSaveButtonAtTop.WaitForAsync();
            await clickOnSaveButtonAtTop.ClickAsync();
        }

        //View A Template *******START   ****
        public async Task NavigateToMyApplications()
        {
            await clickOnMyApplicationsTab.WaitForAsync();
            await clickOnMyApplicationsTab.ClickAsync();
        }

        public async Task HoverImportantNoticeAsync()
        {
            Assert.True(await importantNoticeDisplay.IsVisibleAsync(), "Important Notice is not displayed");
            bool importantNoticeDisplayimg = await importantNoticeDisplay.IsVisibleAsync();
            
            await importantNoticeDisplay.HoverAsync();

            await alertWindow.WaitForAsync();

            IFrame alertsFrame = null;


            for (int i = 0; i < 10; i++)
            {
                alertsFrame = _page.Frames
                    .FirstOrDefault(f => f.Url.Contains("SystemAlerts.aspx"));

                if (alertsFrame != null)
                    break;

                await Task.Delay(500);
            }

            if (alertsFrame == null)
                throw new Exception(" SystemAlerts frame not found");


            //  Click first Show Content
            var showContent = alertsFrame.Locator("text=Show Content").First;

            await showContent.WaitForAsync();
            await showContent.ClickAsync();


            var description = alertsFrame.Locator("#reAnnouncement p");

            await description.WaitForAsync();
            string text = await description.InnerTextAsync();
            Console.WriteLine("Description of announcement is : " + text);
        }
        //View A Template ****  END   ****

        //Announcements

        public async Task ClickOnSearchExistingAnnouncemtnsAsync()
        {
            await clickNoticeAdminTab.WaitForAsync();
            await clickNoticeAdminTab.ClickAsync();
            await clickOnSearchExistingAnnouncemtnsButton.WaitForAsync();
            await clickOnSearchExistingAnnouncemtnsButton.ClickAsync();
        }
        public async Task AnnouncementsDisplayScreenAsync()
        {
            await clickOnShowContentButtons.WaitForAsync();
            await clickOnShowContentButtons.ClickAsync();
            Assert.True(await descriptionContentDisplay.IsVisibleAsync(), "Descriptions content of announcement is not displayed");
           
            await clickOnDeleteButton.WaitForAsync();
            await clickOnDeleteButton.ClickAsync();
            await clickOnCloseButtons.WaitForAsync();
            await clickOnCloseButtons.ClickAsync();
        }

        //Get_User_Email_List

        public async Task GetUserEmailButtonsAsync()
        {
            // Register dialog handler FIRST
            _page.Dialog += async (_, dialog) =>
            {
                Console.WriteLine(dialog.Message);
                await dialog.AcceptAsync();
            };

            await clickonGetUserEmailButtons.WaitForAsync();
            await clickonGetUserEmailButtons.ClickAsync();
            await Task.Delay(4000);

            await clickOnCopyToClipBoard.WaitForAsync();
            await clickOnCopyToClipBoard.ClickAsync();
        }

        //Cancel Button
        public async Task ClickOnCancelButtonAsync()
        {
            await clickOnCancelButton.WaitForAsync();
            await clickOnCancelButton.ClickAsync();
            string titleAfterCanel = await enterDataIntoTitleFiled.InnerTextAsync();

            if (titleAfterCanel == null)
            {
                throw new Exception("There is no data in title field");
            }

        }
    }

}
