using AutomationFrameWork.Drivers;
using AutomationFrameWork.PageActions;
using AutomationFrameWork.Utilities;

namespace AutomationFrameWork.StepDefinitions
{
    [Binding]
    public class NoticeAdminStepDefinitions
    {
        private readonly TestContext _testContext;
        private readonly NoticeAdminPages _noticeAdminPages;

        public NoticeAdminStepDefinitions(PlaywrightDriver playwrightDriver, ScenarioContext scenarioContext)
        {
            _testContext = new TestContext(playwrightDriver.Page, scenarioContext);
            _noticeAdminPages = new NoticeAdminPages(_testContext, playwrightDriver.Page);
        }
        [Given("user should select the General Outage from Choose Template dropdown")]
        public async Task GivenUserShouldSelectTheGeneralOutageFromChooseTemplateDropdown()
        {
            await _noticeAdminPages.clickOnNoticeAdminAsync();
        }

        [When("user fills all the details")]
        public async Task WhenUserFillsAllTheDetails()
        {
            await _noticeAdminPages.GeneralOutageDropdownSelectAsync();
            await _noticeAdminPages.SelectDefaultDatesAsync();

        }

        [When("user selects an application group")]
        public async Task WhenUserSelectsAnApplicationGroup()
        {
            await _noticeAdminPages.SelectApplicationGroupAsync();
        }

        [Then("applications should display and select application")]
        public async Task ThenApplicationsShouldDisplayAndSelectApplication()
        {
            await _noticeAdminPages.SelectApplicationNameAsync();
        }

        [Then("user fill announcement content box")]
        public async Task ThenUserFillAnnouncementContentBox()
        {
            await _noticeAdminPages.AnnounemetnContentBoxFillAsync();
        }

        [Then("user click on Save content template and  click on save")]
        public async Task ThenUserClickOnSaveContentTemplateAndClickOnSave()
        {
            await _noticeAdminPages.SaveAsTemplateAsync();
            await _noticeAdminPages.ClickOnContentTemaplateAndSAveBTnAsync();
        }

        //View of announcement
        [When("user navigates to My Applications")]
        public async Task WhenUserNavigatesToMyApplications()
        {
            await _noticeAdminPages.NavigateToMyApplications();
        }

        [Then("user should be able to see the Important Notice and hover")]
        public async Task ThenUserShouldBeAbleToSeeTheImportantNoticeAndHover()
        {
            await _noticeAdminPages.HoverImportantNoticeAsync();
        }

        [Then("user should see the description by clicking on Show Content")]
        public async Task ThenUserShouldSeeTheDescriptionByClickingOnShowContent()
        {
            await Task.Delay(500);
        }


        //Search_Existing_Announcements
        [Given("user is on Notice admins screen")]
        public async Task GivenUserIsOnNoticeAdminsScreen()
        {
            await _noticeAdminPages.ClickOnSearchExistingAnnouncemtnsAsync();
        }

        [When("click on search existing announcements then all should display")]
        public async Task WhenClickOnSearchExistingAnnouncementsThenAllShouldDisplay()
        {
            await _noticeAdminPages.AnnouncementsDisplayScreenAsync();
        }
        //Search_Existing_Announcements  *****  END  ******

        //Get_User_Email_List
        [Given("user should select as template from Choose Template dropdown")]
        public async Task GivenUserShouldSelectAsTemplateFromChooseTemplateDropdown()
        {
            await _noticeAdminPages.clickOnNoticeAdminAsync();
            await _noticeAdminPages.GeneralOutageDropdownSelectAsync();
        }
        [When("user click on get user email list buttons that all emails should display then cick on copy to clipboard")]
        public async Task WhenUserClickOnGetUserEmailListButtonsThatAllEmailsShouldDisplayThenCickOnCopyToClipboard()
        {
            await _noticeAdminPages.GetUserEmailButtonsAsync();

        }

        //Get_User_Email_List
        //Cancel Buttons

        [When("user is on notice admin screen and clicks on cancel buttons")]
        public async Task WhenUserIsOnNoticeAdminScreenAndClicksOnCancelButtons()
        {
            await _noticeAdminPages.clickOnNoticeAdminAsync();
            await _noticeAdminPages.GeneralOutageDropdownSelectAsync();
        }

        [Then("page should refresh and data should clear")]
        public async Task ThenPageShouldRefreshAndDataShouldClear()
        {
            await _noticeAdminPages.ClickOnCancelButtonAsync();
        }
    }
}
