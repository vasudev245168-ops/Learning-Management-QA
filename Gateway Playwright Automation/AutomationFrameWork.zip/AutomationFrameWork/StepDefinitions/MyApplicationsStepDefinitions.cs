using AutomationFrameWork.Drivers;
using AutomationFrameWork.PageActions;
using AutomationFrameWork.Utilities;

namespace AutomationFrameWork.StepDefinitions
{
    [Binding]
    public class MyApplicationsStepDefinitions
    {
        private readonly TestContext _testContext;
        private readonly MyApplicationsPages _myApplicationsPages;

        public MyApplicationsStepDefinitions(PlaywrightDriver playwrightDriver, ScenarioContext scenarioContext)
        {
            _testContext = new TestContext(playwrightDriver.Page, scenarioContext);
            _myApplicationsPages = new MyApplicationsPages(_testContext, playwrightDriver.Page);
        }

        [Then("user should click on My Reports and Notice Admin Tabs to verify navigation")]
        public async Task ThenUserShouldClickOnMyReportsAndNoticeAdminTabsToVerifyNavigation()
        {
            await _myApplicationsPages.GatewayTabsNavAsync();
        }

        [Given("user is on My Applications page")]
        public async Task GivenUserIsOnMyApplicationsPage()
        {
            await _myApplicationsPages.MyApplicationsScreenValidationAsync();
        }

        [When("user drag and drop application from My Applications to My Favorites")]
        public async Task WhenUserDragAndDropApplicationFromMyApplicationsToMyFavorites()
        {
            await _myApplicationsPages.DragFirstAppFromEachArea();
        }

        [Then("user access application from My Favorites")]
        public async Task ThenUserAccessApplicationFromMyFavorites()
        {
            var results = await _myApplicationsPages.LaunchAppAsync();

            Console.WriteLine("App Validation Results");

            foreach (var r in results)
            {
                Console.WriteLine($"{r.AppName} | {r.Status} | {r.Message}");
            }
        }
        [Then("user should be able to remove the applications from My favorites")]
        public async Task ThenUserShouldBeAbleToRemoveTheApplicationsFromMyFavorites()
        {
            await _myApplicationsPages.RemoveAllAppsFromMyFavoritesAsync();
        }

        [Then("user access application from Available Applications")]
        public async Task ThenUserAccessApplicationFromAvailableApplications()
        {
            await _myApplicationsPages.LaunchApplicationFromMyApplicationsTabAsync();
        }
    }
}
