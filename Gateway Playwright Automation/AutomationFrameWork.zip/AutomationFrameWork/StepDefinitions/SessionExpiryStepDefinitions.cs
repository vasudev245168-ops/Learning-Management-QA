using AutomationFrameWork.Drivers;
using AutomationFrameWork.PageActions;
using AutomationFrameWork.Utilities;

namespace AutomationFrameWork.StepDefinitions
{
    [Binding]
    public class SessionExpiryStepDefinitions
    {
        private readonly TestContext _testContext;
        private readonly SessionExpiryPages _sessionExpiryPages;

        public SessionExpiryStepDefinitions(PlaywrightDriver playwrightDriver, ScenarioContext scenarioContext)
        {
            _testContext = new TestContext(playwrightDriver.Page, scenarioContext);
            _sessionExpiryPages = new SessionExpiryPages(_testContext, playwrightDriver.Page);
        }
        [When("user is idle for more than one  then Session timeout message should be displayed")]
        public async Task WhenUserIsIdleForMoreThanOneThenSessionTimeoutMessageShouldBeDisplayed()
        {
            await Task.Delay(30000);
            await _sessionExpiryPages.ValidateSessionReminderMessage();
        }

       

        [Then("user clicks on Continue button, System remains on Same page")]
        public async Task ThenUserClicksOnContinueButtonSystemRemainsOnSamePage()
        {
            await _sessionExpiryPages.ValidateContinueButtonFunctionality();
        }

        [Then("if user clicks on Logout button, System navigates to Logout page")]
        public async Task ThenIfUserClicksOnLogoutButtonSystemNavigatesToLogoutPage()
        {
            await Task.Delay(31000);
            await _sessionExpiryPages.ValidateLogoutButtonFunctionality();
        }
    }
}
