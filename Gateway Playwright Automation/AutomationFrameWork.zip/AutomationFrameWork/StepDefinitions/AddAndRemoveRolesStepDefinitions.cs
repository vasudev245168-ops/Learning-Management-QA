using AutomationFrameWork.Drivers;
using AutomationFrameWork.PageActions;
using AutomationFrameWork.Utilities;

namespace AutomationFrameWork.StepDefinitions
{
    [Binding]
    public class AddAndRemoveRolesStepDefinitions
    {
        private readonly TestContext _testContext;
        private readonly AddAndRemoveRolesPages _addAndRemoveRolesPages;

        public AddAndRemoveRolesStepDefinitions(PlaywrightDriver playwrightDriver, ScenarioContext scenarioContext)
        {
            _testContext = new TestContext(playwrightDriver.Page, scenarioContext);
            _addAndRemoveRolesPages = new AddAndRemoveRolesPages(_testContext, playwrightDriver.Page);
        }
        [Given("user is on My Applications Screen")]
        public async Task GivenUserIsOnMyApplicationsScreen()
        {
            await _addAndRemoveRolesPages.NavigatedToMyApplicationsTabAsync();
        }

        [When("user validates Notice admin tab display")]
        public async Task WhenUserValidatesNoticeAdminTabDisplay()
        {
            await _addAndRemoveRolesPages.NoticeAdminTabDisplayAsync();
        }

        [Then("Login to control center and remove administrator role")]
        public async Task ThenLoginToControlCenterAndRemoveAdministratorRole()
        {
            var configReader = _testContext.ScenarioContext.Get<ConfigReader>("ConfigReader");
            await _testContext.Page.GotoAsync(configReader.Urls.ControlCenter);
            await _addAndRemoveRolesPages.RemoveAdminUserRoleFromControlCenterAsync();
        }

        [Then("Login back to Gateway and validate Notice Admin Tab should not display")]
        public async Task ThenLoginBackToGatewayAndValidateNoticeAdminTabShouldNotDisplay()
        {
            var configReader = _testContext.ScenarioContext.Get<ConfigReader>("ConfigReader");
            await _testContext.Page.GotoAsync(configReader.Urls.Gateway);
            await _addAndRemoveRolesPages.ValidateNoticeAdminTabRemoveAsync();
        }

    }
}
