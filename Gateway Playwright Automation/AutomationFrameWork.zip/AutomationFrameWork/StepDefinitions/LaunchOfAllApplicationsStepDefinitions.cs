using AutomationFrameWork.Drivers;
using AutomationFrameWork.PageActions;
using AutomationFrameWork.Utilities;

namespace AutomationFrameWork.StepDefinitions
{
    [Binding]
    public class LaunchOfAllApplicationsStepDefinitions
    {
        private readonly TestContext _testContext;
        private readonly LaunchOfAllApplicationsPages _launchOfAllApplicationsPages;
        private readonly ScenarioContext _scenarioContext;
        public LaunchOfAllApplicationsStepDefinitions(PlaywrightDriver playwrightDriver, ScenarioContext scenarioContext)
        {
            _testContext = new TestContext(playwrightDriver.Page, scenarioContext);
            _launchOfAllApplicationsPages = new LaunchOfAllApplicationsPages(_testContext, playwrightDriver.Page,  scenarioContext);
        }

        [When("user click on logout then user logout from gateway")]
        public async Task WhenUserClickOnLogoutThenUserLogoutFromGateway()
        {
            await _launchOfAllApplicationsPages.LogoutFromGatewayAsync();
        }

        [Then("user login to Control Center and assign all the roles in all app areas")]
        public async Task ThenUserLoginToControlCenterAndAssignAllTheRolesInAllAppAreas()
        {
            var configReader = _testContext.ScenarioContext.Get<ConfigReader>("ConfigReader");
            await _testContext.Page.GotoAsync(configReader.Urls.ControlCenter);
            await _launchOfAllApplicationsPages.AddAllRolesInControlCenterAsync();
        }

        [Then("user should be able to launch all the applications successfully in each app area")]
        public async Task ThenUserShouldBeAbleToLaunchAllTheApplicationsSuccessfullyInEachAppArea()
        {
            var configReader = _testContext.ScenarioContext.Get<ConfigReader>("ConfigReader");
            await _testContext.Page.GotoAsync(configReader.Urls.Gateway);
            await _launchOfAllApplicationsPages.LaunchApplicationFromMyApplicationsTabAsync();
        }

    }
}
