using AutomationFrameWork.Drivers;
using AutomationFrameWork.PageActions;
using AutomationFrameWork.Utilities;

namespace AutomationFrameWork.StepDefinitions
{
    [Binding]
    public class MyReportsStepDefinitions
    {
        private readonly TestContext _testContext;
        private readonly MyReportsPages _myReportsPages;

        public MyReportsStepDefinitions(PlaywrightDriver playwrightDriver, ScenarioContext scenarioContext)
        {
            _testContext = new TestContext(playwrightDriver.Page, scenarioContext);
            _myReportsPages = new MyReportsPages(_testContext, playwrightDriver.Page);
        }

        [Given("user is on reports screen")]
        public async Task GivenUserIsOnReportsScreen()
        {
            await _myReportsPages.ClickOnMyReportsAsync();
        }

        [When("user should be able to see all the reports")]
        public async Task WhenUserShouldBeAbleToSeeAllTheReports()
        {
            await _myReportsPages.DisplayOfReportsAsync();
        }

        [Then("user should open all the reports")]
        public async Task ThenUserShouldOpenAllTheReports()
        {
            await _myReportsPages.LaunchOfUserAccessReportsAsync();
            await _myReportsPages.LaunchOfEmployeeInactivityReportsAsync();
        }

    }
}
