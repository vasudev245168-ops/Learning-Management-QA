﻿using AutomationFrameWork.Drivers;
using AutomationFrameWork.PageActions;
using AutomationFrameWork.Utilities;
using static Microsoft.Playwright.Assertions;
namespace AutomationFrameWork.StepDefinitions
{
    [Binding]
    public class LoginStepDefinitions
    {
        private readonly TestContext _testContext;
        private readonly LoginPages _loginPages;

        public LoginStepDefinitions(PlaywrightDriver playwrightDriver, ScenarioContext scenarioContext)
        {
            _testContext = new TestContext(playwrightDriver.Page, scenarioContext);
            _loginPages = new LoginPages(_testContext, playwrightDriver.Page);
        }
        [Given("user is on login page")]
        public async Task GivenUserIsOnLoginPage()
        {
            var configReader = _testContext.ScenarioContext.Get<ConfigReader>("ConfigReader");
            await _loginPages.NavigateAsync(configReader.Urls.Gateway);
        }


        [Then("user should be logged in successfully")]
        public async Task ThenUserShouldBeLoggedInSuccessfully()
        {
            var pageTitle = await _testContext.Page.TitleAsync();
            Console.WriteLine("Page title: " + pageTitle);
            Assert.Contains("Gateway", pageTitle);
        }

        [Then("user must logout on clicking the logout button")]
        public async Task ThenUserMustLogoutOnClickingTheLogoutButton()
        {
            await _loginPages.LogoutAsync();
        }

    }
}
