﻿using Microsoft.Playwright;

namespace AutomationFrameWork.PageElements
{
    public class LoginObjects
    {
        private readonly IPage _page;
        public LoginObjects(IPage page)
        {
            _page = page;
        }
        public ILocator EmailTextField => _page.Locator("input[name='loginfmt']");
        public ILocator ClickOnNextButton => _page.Locator("[value='Next']");
        public ILocator PasswordTextField => _page.Locator("input[name='passwd']");
        public ILocator ClickOnSignInBtn => _page.Locator("[value='Sign in']");

        public ILocator LogOutBtn => _page.GetByText("Logout");


    }
}