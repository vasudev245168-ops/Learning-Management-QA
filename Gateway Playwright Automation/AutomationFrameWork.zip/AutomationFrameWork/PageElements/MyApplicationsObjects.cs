﻿using Microsoft.Playwright;

namespace AutomationFrameWork.PageElements
{
    public class MyApplicationsObjects
    {
        private readonly IPage _page;
        public MyApplicationsObjects(IPage page)
        {
            _page = page;
        }
        public ILocator headerMyReportsNavCheck => _page.GetByRole(AriaRole.Link, new() { Name = "My Reports" });
        public ILocator headerNoticeAdminNavCheck => _page.GetByRole(AriaRole.Link, new() { Name = "Notice Admin" });
        public ILocator UsernameDisplay => _page.Locator("span[class='user-name']");
        public ILocator AvailableApplicationSectionDisplay => _page.Locator("//td[contains(text(),'Available Applications:')]");

        //DragAndDropToMyFavorites     *** START  ****

        public ILocator AllAppAreas => _page.Locator("//li[contains(@class,'rtLI') and .//span[contains(@class,'rtPlus') or contains(@class,'rtMinus')]]");

        // Expand icon inside each area
        public ILocator ExpandIcon(ILocator area) =>
    area.Locator(".//span[contains(@class,'rtPlus')]");

        // First app under expanded area (scoped)
        public ILocator dragFromLocator =>
            _page.Locator("ul[style*='overflow: visible'] .rtIn").First;

        public ILocator dragToLocator => _page.Locator("//div[contains(@class,'rgDataDiv')]");
        public ILocator collapseIcon => _page.Locator("[class='rtMinus']");

        //DragAndDropToMyFavorites     *** END  ****

        //LaunchApplicationFromMyFavorite     *** START  ****
        public ILocator launchFirstAppForEachArea =>
            _page.Locator("//tr[contains(@class,'rgGroupHeader')]/following-sibling::tr[contains(@class,'rgRow') or contains(@class,'rgAltRow')][1]//a");

        //LaunchApplicationFromMyFavorite     *** END  ****

        //Remove all applications from My Favorites    ***START  ****

        public ILocator noRecordsFoundInMyFavorites => _page.GetByText("No records to display.");

        //Remove all applications from My Favorites    ***  END  ****



    }
}
