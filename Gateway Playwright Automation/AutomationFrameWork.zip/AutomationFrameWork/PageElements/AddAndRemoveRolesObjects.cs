﻿using Microsoft.Playwright;

namespace AutomationFrameWork.PageElements
{
    public class AddAndRemoveRolesObjects
    {
        private readonly IPage _page;
        public AddAndRemoveRolesObjects(IPage page)
        {
            _page = page;
        }
        //Gateway Notice admin Tab Display validation
        public ILocator MyApplicationsNavigation => _page.Locator("//span[text()='My Applications']");
        public ILocator ClickLogoutButton => _page.Locator("//a[text()='Logout']");
        public ILocator NoticeAdminTabDisplay => _page.Locator("//span[text()='Notice Admin']");

        //Login to Control Center remove the administration role

        // User Navigates to Add New Employee screen
        public ILocator AddNewEmployeeScreenNavigate => _page.GetByRole(AriaRole.Link, new() { Name = "Add New Employee" });

        // Entering an Employee Id in Corp Login input field and checking the status
        public ILocator CorpLoginInputField => _page.Locator("#ctl00_ContentPlaceHolder1_txtEmployeeID");
        public ILocator AppAreaDropdown => _page.Locator("select[id*='cboProject']");
        public ILocator GatewayApplicationAccess => _page.GetByText("Gateway - Application Access");
        public ILocator SecurityAdminAccess => _page.GetByText("Security Admin");
        public ILocator CurrentRolesAnnouncementAdminRole => _page.Locator("//select[contains(@id,'Current')]//option[text()='Announcement Administrators']");
        public ILocator AvailableRolesAnnouncementAdminRole => _page.Locator("//select[contains(@id,'Available')]//option[text()='Announcement Administrators']");

        //Remove Button
        public ILocator RemoveButton => _page.Locator("[id='ctl00_ContentPlaceHolder1_btnRemove']");

        // Add button
        public ILocator AddButton => _page.Locator("[id='ctl00_ContentPlaceHolder1_btnAdd']");

        // Save button
        public ILocator SaveButton => _page.Locator("input[value='Save']");

        // Popup YES button
        public ILocator UnsavedChangesPendingPopUp => _page.Locator("[id='ctl00_ContentPlaceHolder1_radWindowConfirm_C']");

        public ILocator YesButton => _page.Locator("input[value='Yes']");



       
    }
}
