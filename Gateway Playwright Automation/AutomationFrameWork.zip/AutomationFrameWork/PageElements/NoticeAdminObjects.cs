﻿using Microsoft.Playwright;

namespace AutomationFrameWork.PageElements
{
    public class NoticeAdminObjects
    {
        private readonly IPage _page;
        public NoticeAdminObjects(IPage page)
        {
            _page = page;
        }

        //Click on Notice Admin Tab
        public ILocator clickNoticeAdminTab => _page.GetByRole(AriaRole.Link, new() { Name = "Notice Admin" });

        //Create A Template *******START   ****
        public ILocator clickOnChooseTemplateDropdown => _page.Locator(".rddlFakeInput").First;
        public ILocator selectGeneralOutageOption => _page.GetByText("General Outage");
        public ILocator enterDataIntoTitleFiled => _page.Locator("#ctl00_ContentPlaceHolder1_txtTitle");
        public ILocator startDate => _page.Locator("#ctl00_ContentPlaceHolder1_rdtpStartIndia_dateInput");
        public ILocator endDate => _page.Locator("#ctl00_ContentPlaceHolder1_rdtpEndIndia_dateInput");

        public ILocator clickapplicationGroupDropdown => _page.Locator(".rddlInner").Nth(1);
        public ILocator selectLoanServicingApplication => _page.Locator("//li[text()='Shared Services']");
        public ILocator selectApplicationName => _page.Locator("[id*='lstApplications'] span").First;
        public IFrameLocator announcementCotentBoxFrame => _page.FrameLocator("[id='ctl00_ContentPlaceHolder1_reAnnouncementContent_contentIframe']");
        public ILocator enterAnnouncementContent => announcementCotentBoxFrame.Locator("body").Nth(0);

        public ILocator clickOnSaveContentTemplate => _page.Locator("#ctl00_ContentPlaceHolder1_btnSaveTemplate_input\r\n");
        public ILocator clickOnSaveButtonAtTop => _page.Locator("input[value='Save']");
        //Create A Template *******END   ****

        //View A Template *******START   ****
        public ILocator clickOnMyApplicationsTab => _page.GetByText("My Applications");
        public ILocator importantNoticeDisplay => _page.Locator("img[id='AlertImage']");
        public ILocator alertWindow => _page.Locator("#AlertWindow");
        public IFrameLocator showContentIframe => _page.FrameLocator("#rgAnnouncements_ctl00 tr").Nth(1);
        //View A Template *******END   ****

        //Existing Announcements
        public ILocator clickOnSearchExistingAnnouncemtnsButton => _page.Locator("[value='Search Existing Announcements']");
        public ILocator clickOnShowContentButtons => _page.GetByRole(AriaRole.Link, new() { Name = "Show Content" }).First;
        public ILocator descriptionContentDisplay => _page.Locator("//div[@id='reAnnouncement']//p").Nth(0);
        public ILocator clickOnDeleteButton => _page.GetByRole(AriaRole.Link, new() { Name = "Delete" }).First;
        public ILocator clickOnCloseButtons => _page.Locator("#btnClose");

        //Get_User_Email_List
        public ILocator clickonGetUserEmailButtons => _page.Locator("input[value='Get User Email List']");
        public ILocator clickOnCopyToClipBoard => _page.Locator("#ctl00_ContentPlaceHolder1_btnCopy");

        //Cancel Button
        public ILocator clickOnCancelButton => _page.Locator("[id='ctl00_ContentPlaceHolder1_btnCancel_input']");


    }
}
