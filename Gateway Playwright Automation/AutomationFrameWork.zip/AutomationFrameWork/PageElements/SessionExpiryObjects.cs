﻿using Microsoft.Playwright;

namespace AutomationFrameWork.PageElements
{
    public class SessionExpiryObjects
    {
        private readonly IPage _page;
        public SessionExpiryObjects(IPage page)
        {
            _page = page;
        }
        public ILocator ContinueBtn => _page.Locator("//button[text()='Continue']");
        public ILocator LogoutBtn => _page.Locator("//button[text()='Logout']");
        public ILocator SessionReminderHeader => _page.Locator("//div[@id='titleDiv']");
        public ILocator SessionTimeoutText => _page.Locator("//div[@id='messageDiv']");
        public ILocator ClickhereTextlink => _page.Locator("//a[text()='Click here']");
        public ILocator SignoutAccount => _page.Locator("//img[@class='tile-img']");
        public ILocator SuccessfulLogoutMsg => _page.Locator("//div[@id='login_workload_logo_text']");
    }
}
