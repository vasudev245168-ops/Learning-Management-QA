﻿using Microsoft.Playwright;

namespace AutomationFrameWork.PageElements
{
    public class LaunchOfAllApplicationsObjects
    {
        private readonly IPage _page;
        public LaunchOfAllApplicationsObjects(IPage page)
        {
            _page = page;
        }
        public ILocator AvailableApplicationSectionDisplay => _page.Locator("//td[contains(text(),'Available Applications:')]");

        public ILocator LogOutBtn => _page.GetByText("Logout");

        // User Navigates to Add New Employee screen
        public ILocator AddNewEmployeeScreenNavigate => _page.GetByRole(AriaRole.Link, new() { Name = "Add New Employee" });

        // Entering an Employee Id in Corp Login input field and checking the status
        public ILocator CorpLoginInputField => _page.Locator("#ctl00_ContentPlaceHolder1_txtEmployeeID");
        public ILocator AppAreaDropdown => _page.Locator("select[id*='cboProject']");
        public ILocator AvailableRoles => _page.Locator("[id*='lstAvailableGroups'] option");
        public ILocator CurrentRolesADMINUserRole => _page.Locator("//select[contains(@id,'Current')]//option[text()='WebRetrieval - Admin User']");
        public ILocator AvailableRolesADMINUserRole => _page.Locator("//select[contains(@id,'Available')]//option[text()='WebRetrieval - Admin User']");

        //Remove Button
        public ILocator RemoveButton => _page.Locator("[id='ctl00_ContentPlaceHolder1_btnRemove']");

        // Add button
        public ILocator AddButton => _page.Locator("[id='ctl00_ContentPlaceHolder1_btnAdd']");
        public ILocator ClickOnAddAllButton => _page.Locator("input[id='ctl00_ContentPlaceHolder1_btnAddAll']");

        // Save button
        public ILocator SaveButton => _page.Locator("input[value='Save']");

        // Popup YES button
        public ILocator UnsavedChangesPendingPopUp => _page.Locator("[id='ctl00_ContentPlaceHolder1_radWindowConfirm_C']");

        public ILocator YesButton => _page.Locator("input[value='Yes']");
        public ILocator ValidateAppPage => _page.Locator("//span[contains(@id,'lblUserName')]");
    }
}
