﻿using Microsoft.Playwright;

namespace AutomationFrameWork.PageElements
{
    public class MyReportsObjects
    {
        private readonly IPage _page;
        public MyReportsObjects(IPage page)
        {
            _page = page;
        }
        public ILocator clickOnMyReportsTab => _page.GetByRole(AriaRole.Link, new() { Name = "My Reports" });
        public ILocator clickOnMyReportsSortingIcon => _page.Locator("th a[title='Click here to sort']");
        public ILocator reportsScreenHeader => _page.Locator(".UserFormHeader");

        public ILocator gatewayDropdownTextDispaly => _page.GetByText("Gateway", new() { Exact = false }).First;
        public ILocator userAccessReport => _page.GetByRole(AriaRole.Link, new() { Name = "User Access Report" });

        public ILocator employeeInactivityReport => _page.GetByRole(AriaRole.Link, new() { Name = "Employee Inactivity Report" });
        //ifrmae
        public IFrameLocator bothReportsScreenFrame => _page.FrameLocator("[data-testid='rdl-host-container-iframe']");

        public ILocator reportsLoadsValidation => bothReportsScreenFrame.Locator("table").First;
        public ILocator viewReportButtonDispaly => bothReportsScreenFrame.GetByRole(AriaRole.Button, new() { Name = "View report" });
    }
}
